package hust.soict.globalict.garbage;

public class GarbageCreator {

}
