package hust.soict.dsai.aims.media; //Nguyễn Văn Nam - 20215097

public interface Playable {
	void play();
}
